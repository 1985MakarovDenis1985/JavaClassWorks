package telran.user.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import telran.user.model.User;

class UserTest {
	User user;
	String email = "peter@gmail.com";
	String password = "123456Ab!";

	@BeforeEach
	void setUp() throws Exception {
		user = new User(email, password);
	}

	@Test
	void testCorrectEmail() {
		String expected = "peter@mail.ru";
		user.setEmail("peter@mail.ru");
		assertEquals(expected, user.getEmail());
	}
	
	@Test
	void testWithoutAt() {
		user.setEmail("peter.mail.ru");
		assertEquals(email, user.getEmail());
	}
	
	@Test
	void testDoubleAt() {
		user.setEmail("peter@ma@il.ru");
		assertEquals(email, user.getEmail());
	}
	
	@Test
	void testDotAfterAt() {
		user.setEmail("peter@mailru");
		assertEquals(email, user.getEmail());
	}
	
	@Test
	void testLastDot() {
		user.setEmail("peter@mailru.");
		assertEquals(email, user.getEmail());
		user.setEmail("peter@mailr.u");
		assertEquals(email, user.getEmail());	
	}
	
	@Test
	void testIncorrectSymbols() {
		user.setEmail("pet!er@mail.ru");
		assertEquals(email, user.getEmail());	
	}
	
	@Test
	void testCorrectPassword() {
		String correctPassword = "qwertY%8";
		user.setPassword(correctPassword);
		assertEquals(correctPassword, user.getPassword());
	}
	
	@Test
	void testPasswordLength() {
		String inCorrectPassword = "qertY%8";
		user.setPassword(inCorrectPassword);
		assertEquals(password, user.getPassword());
	}
	
	@Test
	void testPasswordUpperCase() {
		String inCorrectPassword = "qwerty%8";
		user.setPassword(inCorrectPassword);
		assertEquals(password, user.getPassword());
	}
	
	@Test
	void testPasswordLowerCase() {
		String inCorrectPassword = "QWERTY%8";
		user.setPassword(inCorrectPassword);
		assertEquals(password, user.getPassword());
	}
	
	@Test
	void testPasswordDigits() {
		String inCorrectPassword = "qwerty%E";
		user.setPassword(inCorrectPassword);
		assertEquals(password, user.getPassword());
	}
	
	@Test
	void testPasswordSpecSymbols() {
		String inCorrectPassword = "qwertY_8";
		user.setPassword(inCorrectPassword);
		assertEquals(password, user.getPassword());
	}

}
