package telran.computer.controller;

import telran.computer.model.Computer;
import telran.computer.model.Laptop;
import telran.computer.model.Smartphone;

public class ComputerAppl {

	public static void main(String[] args) {
		Computer comp1 = new Computer("i5", 12, 512, "HP");
		Laptop lap1 = new Laptop("i7", 16, 512, "Asus", 2.1, 2);
		comp1.display();
		System.out.println();
		lap1.display();
		System.out.println();
		Smartphone smart1 = new Smartphone("Snapdragon", 6, 128, "Samsung", 0.2, 8, 1234567890l);
		smart1.display();
		System.out.println();
		System.out.println("=====================");
		System.out.println(comp1);
		System.out.println(lap1);
		System.out.println(smart1);
	}

}
