package telran.computer.model;

public class Computer {
	protected String cpu;
	protected int ram;
	protected int hdd;
	protected String brand;

	public Computer() {
		super();
	}

	public Computer(String cpu, int ram, int hdd, String brand) {
		super();
		this.cpu = cpu;
		this.ram = ram;
		this.hdd = hdd;
		this.brand = brand;
	}

	public String getCpu() {
		return cpu;
	}

	public void setCpu(String cpu) {
		this.cpu = cpu;
	}

	public int getRam() {
		return ram;
	}

	public void setRam(int ram) {
		this.ram = ram;
	}

	public int getHdd() {
		return hdd;
	}

	public void setHdd(int hdd) {
		this.hdd = hdd;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}
	
	public void display() {
		System.out.print("Brand: " + brand + ", CPU: " + cpu +
				", RAM: " + ram + ", HDD: " + hdd);
	}
	
	public String toString() {
		return "Brand: " + brand + ", CPU: " + cpu +
				", RAM: " + ram + ", HDD: " + hdd;
	}

}
