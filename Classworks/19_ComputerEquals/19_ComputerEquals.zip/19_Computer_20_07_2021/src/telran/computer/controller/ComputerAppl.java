package telran.computer.controller;

import telran.computer.model.Computer;
import telran.computer.model.Laptop;
import telran.computer.model.Smartphone;

public class ComputerAppl {

	public static void main(String[] args) {
		Computer[] shop = new Computer[4];
		shop[0] = new Computer("i5", 12, 512, "HP");
		shop[1] = new Laptop("i7", 16, 512, "Asus", 2.1, 2);
		shop[2] = new Smartphone("Snapdragon", 6, 128, "Samsung", 0.2, 8, 1234567890l);
		shop[3] = new Laptop("i7", 16, 1024, "Dell", 2.1, 2);
		
		Computer comp = new Computer("i5", 12, 512, "HP");
		boolean check = comp.equals(shop[0]);
		System.out.println(check);
		check = shop[1].equals(shop[3]);
		System.out.println(check);
		comp = new Laptop("i7", 16, 1024, "Dell", 2.1, 2);
		check = comp.equals(shop[3]);
		System.out.println(check);
	}
	
	

}
