package telran.employee.dao;

import telran.employee.interfaces.ICompany;
import telran.employee.model.Employee;

public class Company implements ICompany{
	private Employee[] employees;
	private int size;
	
	public Company(int capacity) {
		employees = new Employee[capacity];
	}

	@Override
	public boolean addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Employee removeEmployee(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee findEmployee(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public double totalSalary() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int quantity() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double avgSalary() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double totalSales() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void printEmployees() {
		// TODO Auto-generated method stub
		
	}

}
