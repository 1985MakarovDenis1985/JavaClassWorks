package telran.employee.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import telran.employee.dao.Company;
import telran.employee.interfaces.ICompany;
import telran.employee.model.Employee;
import telran.employee.model.Manager;
import telran.employee.model.SalesManager;
import telran.employee.model.WageEmployee;

class CompanyTest {
	ICompany company;
	Employee[] firm;

	@BeforeEach
	void setUp() throws Exception {
		company = new Company(5);
		firm = new Employee[4];
		firm[0] = new Manager(1000, "John", "Smith", 182, 20000, 20);
		firm[1] = new WageEmployee(2000, "Ann", "Smith", 182, 40);
		firm[2] = new SalesManager(3000, "Peter", "Jackson", 182, 40000, 0.1);
		firm[3] = new SalesManager(4000, "Tigran", "Petrosyan", 91, 80000, 0.1);
		for (int i = 0; i < firm.length; i++) {
			company.addEmployee(firm[i]);
		}
	}

	@Test
	void testAddEmployee() {
		assertFalse(company.addEmployee(firm[1]));
		Employee employee = new SalesManager(5000, "Tigran", "Petrosyan", 91, 80000, 0.1);
		assertTrue(company.addEmployee(employee));
		assertEquals(employee, company.findEmployee(5000));
		assertEquals(5, company.quantity());
		employee = new SalesManager(6000, "Tigran", "Petrosyan", 91, 80000, 0.1);
		assertFalse(company.addEmployee(employee));
	}

	@Test
	void testRemoveEmployee() {
		fail("Not yet implemented");
	}

	@Test
	void testFindEmployee() {
		fail("Not yet implemented");
	}

	@Test
	void testTotalSalary() {
		fail("Not yet implemented");
	}

	@Test
	void testQuantity() {
		assertEquals(4, company.quantity());
	}

	@Test
	void testAvgSalary() {
		fail("Not yet implemented");
	}

	@Test
	void testTotalSales() {
		fail("Not yet implemented");
	}

}
