package telran.computer.controller;

import telran.computer.model.Computer;
import telran.computer.model.Laptop;
import telran.computer.model.Smartphone;

public class ComputerAppl {

	public static void main(String[] args) {
		Computer[] shop = new Computer[4];
		shop[0] = new Computer("i5", 12, 512, "HP");
		shop[1] = new Laptop("i7", 16, 512, "Asus", 2.1, 2);
		shop[2] = new Smartphone("Snapdragon", 6, 128, "Samsung", 0.2, 8, 1234567890l);
		shop[3] = new Laptop("i7", 16, 1024, "Dell", 2.1, 2);
		printArray(shop);
		printBrands(shop);
		int totalHdd = totalMemore(shop);
		System.out.println("Total hdd = " + totalHdd);
		int totalHours = totalBatteryHours(shop);
		System.out.println("Total hours: " + totalHours);
		totalHours = totalOnlyLaptopHours(shop);
		System.out.println("Total laptop hours: " + totalHours);
	}
	
	private static int totalOnlyLaptopHours(Computer[] shop) {
		int res = 0;
		for (int i = 0; i < shop.length; i++) {
			if (shop[i] instanceof Laptop && !(shop[i] instanceof Smartphone)) {
				res += ((Laptop) shop[i]).getHours();
			}
		}
		return res;
	}

	private static int totalBatteryHours(Computer[] shop) {
		int res = 0;
		for (int i = 0; i < shop.length; i++) {
			if (shop[i] instanceof Laptop) {
				res += ((Laptop) shop[i]).getHours();
			}
		}
		return res;
	}

	private static int totalMemore(Computer[] shop) {
		int res = 0;
		for (int i = 0; i < shop.length; i++) {
			res += shop[i].getHdd();
		}
		return res;
	}

	private static void printArray(Object[] arr) {
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}
		System.out.println("==============");
	}

	private static void printBrands(Computer[] shop) {
		for (int i = 0; i < shop.length; i++) {
			System.out.println(shop[i].getBrand());
		}
		System.out.println("==============");
	}

}
