package telran.cars.dao;

import java.util.function.Predicate;

import telran.cars.interfaces.IGarage;
import telran.cars.model.Car;

public class Garage implements IGarage {
	private Car[] cars;
	private int size;

	public Garage(int capacity) {
		cars = new Car[capacity];
	}

	@Override
	public boolean addCar(Car car) {
		if (size == cars.length || findCarByRegNumber(car.getRegNumber()) != null) {
			return false;
		}
		cars[size++] = car;
		return true;
	}

	@Override
	public Car removeCar(String regNumber) {
		for (int i = 0; i < size; i++) {
			if (regNumber.equals(cars[i].getRegNumber())) {
				Car temp = cars[i];
				cars[i] = cars[--size];
				return temp;
			}

		}
		return null;
	}

	@Override
	public Car findCarByRegNumber(String regNumber) {
		for (int i = 0; i < size; i++) {
			if (cars[i].getRegNumber().equals(regNumber)) {
				return cars[i];
			}
		}
		return null;
	}
	
	@Override
	public Car[] findCarsByPredicate(Predicate<Car> tester) {
		int count = 0;
		for (int i = 0; i < size; i++) {
			if (tester.test(cars[i])) {
				count++;
			}
		}
		Car[] res = new Car[count];
		for (int i = 0, j = 0; j < res.length; i++) {
			if (tester.test(cars[i])) {
				res[j++] = cars[i];
			}
		}
		return res;
	}

}
