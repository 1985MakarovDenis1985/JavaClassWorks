package telran.products.controller;

import telran.products.dao.Supermarket;
import telran.products.model.MeatFood;
import telran.products.model.MilkFood;
import telran.products.model.Product;

public class SupermarketAppl {

	public static void main(String[] args) {
		Supermarket kiosk = new Supermarket(10);
		boolean check = kiosk.addProduct(new Product(50, "Gift card", 1000));
		System.out.println(check);
		kiosk.addProduct(new MeatFood(70, "Sosages Mizra", 2000, true, "31.07.2021", "beef"));
		kiosk.addProduct(new MilkFood(95, "Goat cheese", 3000, true, "25.08.2021", "goat", 40));
		kiosk.addProduct(new MeatFood(120, "Pork fat", 4000, false, "30.07.2021", "pork"));
		check = kiosk.addProduct(new Product(50, "Gift card", 1000));
		System.out.println(check);
		int sku = kiosk.getCurrentSku();
		System.out.println(sku);
		Product product = kiosk.findProduct(3000);
		System.out.println(product);
		System.out.println("=============");
		kiosk.printProducts();
	}

}
