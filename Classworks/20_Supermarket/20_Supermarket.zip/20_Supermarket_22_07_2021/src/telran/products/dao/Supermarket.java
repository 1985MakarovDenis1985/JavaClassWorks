package telran.products.dao;

import telran.products.model.Product;

public class Supermarket {
	private Product[] products;
	private int currentSku;

	public Supermarket(int capacity) {
		this.products = new Product[capacity];
		// currentSku = 0;
	}

	public int getCurrentSku() {
		return currentSku;
	}

	public boolean addProduct(Product product) {
		if (currentSku < products.length 
				&& findProduct(product.getBarCode()) == null) {
			products[currentSku] = product;
			currentSku++;
			return true;
		}
		return false;
	}

	public Product findProduct(long barCode) {
		for (int i = 0; i < currentSku; i++) {
			if (products[i].getBarCode() == barCode) {
				return products[i];
			}
		}
		return null;
	}
	
	public void printProducts() {
		for (int i = 0; i < currentSku; i++) {
			System.out.println(products[i]);
		}
	}
}
