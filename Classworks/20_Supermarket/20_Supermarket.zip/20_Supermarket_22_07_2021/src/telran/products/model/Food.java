package telran.products.model;

public class Food extends Product {
	private boolean kosher;
	private String expDate;

	public Food(double price, String name, long barCode, boolean kosher, String expDate) {
		super(price, name, barCode);
		this.kosher = kosher;
		this.expDate = expDate;
	}

	public boolean isKosher() {
		return kosher;
	}

	public void setKosher(boolean kosher) {
		this.kosher = kosher;
	}

	public String getExpDate() {
		return expDate;
	}

	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}

	public String toString() {
		return super.toString() + ", Kosher: " + (kosher ? "yes" : "no") + ", Exp. Date: " + expDate;
	}

}
