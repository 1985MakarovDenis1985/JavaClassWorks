package telran.products.model;

public class MeatFood extends Food {
	private String meatType;

	public MeatFood(double price, String name, long barCode, boolean kosher, String expDate, String meatType) {
		super(price, name, barCode, kosher, expDate);
		this.meatType = meatType;
	}

	public String getMeatType() {
		return meatType;
	}

	public void setMeatType(String meatType) {
		this.meatType = meatType;
	}

	public String toString() {
		return super.toString() + ", Meat type: " + meatType;
	}

}
