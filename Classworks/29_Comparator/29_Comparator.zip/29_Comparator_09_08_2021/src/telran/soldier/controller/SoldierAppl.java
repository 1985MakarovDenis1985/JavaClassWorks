package telran.soldier.controller;

import java.util.Arrays;

import telran.arrays.tools.ArrayTools;
import telran.soldier.model.Soldier;

public class SoldierAppl {

	public static void main(String[] args) {
		Soldier[] soldiers = { 
				new Soldier("John", 182, 82.3, 91), 
				new Soldier("Peter", 175, 77.1, 96),
				new Soldier("Tigran", 162, 55.3, 96),
				new Soldier("Mary", 159, 49.1, 91),
				new Soldier("Mosche", 175, 85, 75), 
				new Soldier("Sarah", 162, 55, 91) };
		ArrayTools.printArray(soldiers);
		Arrays.sort(soldiers, (s1, s2) -> Double.compare(s1.getWeight(), s2.getWeight()));
		ArrayTools.printArray(soldiers);
		Arrays.sort(soldiers, (s1, s2) -> {
			int res = Integer.compare(s1.getProfile(), s2.getProfile());
			if(res != 0) {
				return res;
			}
			return s1.getName().compareTo(s2.getName());
		});
		ArrayTools.printArray(soldiers);
	}

}
