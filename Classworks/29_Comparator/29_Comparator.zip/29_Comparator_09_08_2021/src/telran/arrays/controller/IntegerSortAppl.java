package telran.arrays.controller;

import java.util.Arrays;

import telran.arrays.tools.ArrayTools;

public class IntegerSortAppl {

	public static void main(String[] args) {
		Integer[] nums = {
				Integer.MAX_VALUE, 
				-2,
				Integer.MIN_VALUE,		
				-1
		};
		ArrayTools.printArray(nums);
		Arrays.sort(nums, (a,b) -> Integer.compare(b, a));
		ArrayTools.printArray(nums);
	}

}
