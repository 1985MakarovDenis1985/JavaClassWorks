package telran.arrays.controller;

import telran.arrays.tools.ArrayTools;

public class ArraysAppl {

	public static void main(String[] args) {
		Integer[] arrNum = { 9, 7, 4, 7, 2, 5, 9, 1, 0 };
		ArrayTools.printArray(arrNum);
		String[] arrStr = { "one", "two", "three", "four", "five" };
		Integer res = ArrayTools.findByPredicate(arrNum, n -> n % 5 == 0);
		System.out.println("Result = " + res);
		ArrayTools.printArray(arrStr);
		ArrayTools.bubbleSort(arrNum);
		ArrayTools.printArray(arrNum);
		ArrayTools.bubbleSort(arrStr);
		ArrayTools.printArray(arrStr);
	}

}
