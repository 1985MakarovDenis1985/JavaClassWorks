package telran.string.controller;

public class StringAppl {

	public static void main(String[] args) {
		String str = "Hello";
		char[] chars = {' ', 'w', 'o', 'r', 'l', 'd'};
		String str1 = new String(chars);
		str = str + str1; //str.concat(str1);
		System.out.println(str);
		System.out.println(str.length());
		char c = str.charAt(2);
		System.out.println(c);
		for(int i = 0; i < str.length(); i++) {
			System.out.println(str.charAt(i));
		}
		String str3 = " WORLD";
		System.out.println(str1.equalsIgnoreCase(str3));
		String str1Upper = str1.toUpperCase();
		System.out.println(str1Upper);
		System.out.println(str1);
		System.out.println(str3.toLowerCase());
		int index = str.indexOf("lo", 5);
		System.out.println(index);
		index = str.lastIndexOf('l');
		System.out.println(index);
		System.out.println(str.substring(2,4));
		c = 'l';
		System.out.println(str.replace(Character.toString(c), "ZZZ"));
		
	}

}
