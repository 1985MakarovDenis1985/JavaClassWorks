package telran.user.model;

public class User {
	private String email;
	private String password;

	public User(String email, String password) {
		setEmail(email);
		setPassword(password);
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		if (validateEmail(email)) {
			this.email = email;
		} else {
			System.out.println(email + " is not valid");
		}
	}

	private boolean validateEmail(String email) {
		int indexAt = email.indexOf('@');
		if (indexAt == -1 || indexAt != email.lastIndexOf('@')) {
			return false;
		}
		if (email.indexOf('.', indexAt) == -1) {
			return false;
		}
		if (email.lastIndexOf('.') > email.length() - 3) {
			return false;
		}
		for (int i = 0; i < email.length(); i++) {
			char c = email.charAt(i);
			if (!(Character.isDigit(c) || Character.isAlphabetic(c) || c == '_' || c == '-' || c == '.' || c == '@')) {
				return false;
			}
		}
		return true;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		if (validatePassword(password)) {
			this.password = password;
		} else {
			System.out.println("Password not valid");
		}

	}

	private boolean validatePassword(String password) {
		return passwordCode(password) == 31;
//		int len = password.length();
//		boolean[] res = new boolean[5];
//		if (len >= 8) {
//			res[0] = true;
//		}
//		for (int i = 0; i < len; i++) {
//			char c = password.charAt(i);
//			if (Character.isUpperCase(c)) {
//				res[1] = true;
//			}
//			if (Character.isLowerCase(c)) {
//				res[2] = true;
//			}
//			if (Character.isDigit(c)) {
//				res[3] = true;
//			}
//
//			if (isSpecialSymbol(c)) {
//				res[4] = true;
//			}
//		}
//		for (int i = 0; i < res.length; i++) {
//			if (!res[i]) {
//				return false;
//			}
//		}
//		return true;
	}
	
	private static boolean isSpecialSymbol(char c) {
		return "!%@*&".indexOf(c) >= 0;
	}
	
	public byte passwordCode(String password) {
		byte res = 0;
		if(password.length() >= 8) {
			res |= 1; //res = res | 1
		}
		for(int i = 0; i < password.length(); i++) {
			char c = password.charAt(i);
			if (Character.isUpperCase(c)) {
				res |= 2;
			}
			if (Character.isLowerCase(c)) {
				res |= 4;
			}
			if (Character.isDigit(c)) {
				res |= 8;
			}

			if (isSpecialSymbol(c)) {
				res |= 16;
			}
		}
		return res;
	}

	@Override
	public String toString() {
		return "User [email=" + email + ", password=" + password + "]";
	}

}
