package telran.user.controller;

public class BitwiseAppl {

	public static void main(String[] args) {
		int x = Integer.MIN_VALUE;
		System.out.println(x);
		System.out.println(Integer.toBinaryString(x));
		int z = (x >> 1) ;
		System.out.println(z);
		System.out.println(Integer.toBinaryString(z));
		System.out.println("===============");
		int secretKey = 84;
		int message = 5647;
		int encrypt = message ^ secretKey;
		System.out.println(encrypt);
		System.out.println(Integer.toBinaryString(message));
		System.out.println(Integer.toBinaryString(secretKey));
		System.out.println(Integer.toBinaryString(encrypt));
		int decrypt = encrypt ^ secretKey;
		System.out.println(decrypt);
	}

}
