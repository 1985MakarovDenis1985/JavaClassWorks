package telran.regexp.controller;

public class RegExpAppl {

	public static void main(String[] args) {
		String str = "   java99";
		String pattern = "\\s*(J|j)ava\\d{0,2}";
		boolean check = str.matches(pattern);
		System.out.println(check);
		String domain = "peter.il";
		pattern = "\\w+\\.(com|il|ua|ru|by)";
		check = domain.matches(pattern);
		System.out.println(check);
		String email = "peter-jack.son_92@gmail.com";
		pattern = "\\w(\\w|\\.|-)*\\w@\\w(\\w|\\.|-)*\\.[a-zA-Z]{2,6}";
		check = email.matches(pattern);
		System.out.println(check);
		String words = "Mama\n   myla\t ramu";
		String[] arr = words.split("\\s+");
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}
	}

}
