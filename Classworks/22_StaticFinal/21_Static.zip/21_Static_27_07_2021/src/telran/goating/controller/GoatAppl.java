package telran.goating.controller;

import telran.goating.model.Goat;

public class GoatAppl {

	public static void main(String[] args) {
		Goat goating1 = new Goat();
		for(int i = 1; i <= Goat.MAX; i++) {
			goating1.count++;
		}
		System.out.println(goating1.count);
		Goat goating2 = new Goat();
		for(int i = 1; i <= 15; i++) {
			goating2.count++;
		}
		System.out.println(goating2.count);
		System.out.println(goating1.count);
		System.out.println(Math.PI);
	}

}
