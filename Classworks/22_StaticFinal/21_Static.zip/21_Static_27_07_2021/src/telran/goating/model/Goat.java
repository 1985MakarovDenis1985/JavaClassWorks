package telran.goating.model;

public class Goat {
	public static final int MAX = 10;
	public int count;
}
