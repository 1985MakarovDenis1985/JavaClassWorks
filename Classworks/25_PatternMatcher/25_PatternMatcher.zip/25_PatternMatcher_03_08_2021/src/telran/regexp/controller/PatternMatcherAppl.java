package telran.regexp.controller;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PatternMatcherAppl {

	public static void main(String[] args) {
		String str = "Don't trouble Trouble until" + " trouble troubles you";
		String regex = "(t|T)rouble\\w*";
		// System.out.println(str.matches(regex));
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(str);
		System.out.println(matcher.matches());
		boolean res = matcher.find();
		System.out.println(res);
		System.out.println(matcher.start());
		System.out.println(matcher.group());
		System.out.println(matcher.end());
		res = matcher.find();
		System.out.println(res);
		System.out.println(matcher.start());
		System.out.println(matcher.group());
		System.out.println(matcher.end());
		System.out.println("=================");
		matcher.reset();
		while (matcher.find()) {
			System.out.println(matcher.start());
			System.out.println(matcher.group());
			System.out.println(matcher.end());
		}
		System.out.println("=================");
		String str1 = "All my troubles seemed so far away";
		matcher.reset(str1);
		while (matcher.find()) {
			System.out.println(matcher.start());
			System.out.println(matcher.group());
			System.out.println(matcher.end());
		}
	}

}
