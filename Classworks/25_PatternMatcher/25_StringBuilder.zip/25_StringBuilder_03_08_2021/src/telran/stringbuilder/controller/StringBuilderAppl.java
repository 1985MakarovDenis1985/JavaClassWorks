package telran.stringbuilder.controller;

public class StringBuilderAppl {

	public static void main(String[] args) {
		StringBuilder builder = new StringBuilder("Java");
		builder.append(8);
		System.out.println(builder.reverse());
		String str = builder.toString();
		System.out.println(str);
		str = stringManipulation("mama");
		System.out.println(str);
	}

	private static String stringManipulation(String str) {
		StringBuilder builder = new StringBuilder(str);
		builder.append(" myla").append(" ramu");
		builder.reverse();
		return builder.toString();
	}

}
